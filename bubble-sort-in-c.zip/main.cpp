# include<bits/stdc++.h>
using namespace std;
void bubble(vector<int>&arr){
int n=arr.size();
for  (int i=0;i<arr.size();i++){
    for(int j=0;j<n-1;j++){
        if(arr[j]>arr[j+1]){
            swap(arr[j],arr[j+1]);
        }
    }
}
}
int main(){
    int n;
    cout<<"Enter the size of numebr ";
    cin>>n;
    vector<int>arr(n) ;
    cout<<"Enter the array for sort";
    for(int i=0;i<n;i++){
        cin>>arr[i];
        
    }
    bubble(arr);
    cout<<"Here is the soreted array=";
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    
}